package ufl.cs1.controllers;

import game.controllers.DefenderController;
import game.models.Defender;
import game.models.Game;

import java.util.List;

// Hey Boys this is gonna be fun
public final class StudentController implements DefenderController {

	// Private Variable Declarations
	Game previousGameState;
	Game CurrentGameState;
	private StudentController.GenericState[] PreviousGhostState = new StudentController.GenericState[]{null, null, null, null};
	private StudentController.GenericState[] CurrentGhostState;


	// Implemented Methods
	public void init(Game game) {
	}

	public void shutdown(Game game) {
	}

	public int[] update(Game game, long CurrentGameTime) {
		int[] actions = {-1, -1, -1, -1};

		// Up - Right - Down - Left -> 0 - 1 - 2 - 3
		// Anything else is no change
		return actions;
	}

	// New Methods
	public interface GenericState {
		void UpdateStateTimer(long CurrentGameTime);

		StudentController.StateType getStateType();

		StudentController.StateType nextStateType(int ghost);

		int getDirectionToMove(int ghost);

		void Reset();
	}

	// Types if States
	static enum StateType {
		Hunting,
		Flee,
		Lair,
		NoChange;
	}

	// Declares Methods for each of the Ghost States

	// Hunting down Pac-Man, two ghost going directly for Pac-Man, two more going around to try to stop Pac-Man from eating Power Pills
	public class HuntState implements GenericState {
		private long previoustime;
		private long delayTimer;
		private long timer;

		// Constructor for HuntState
		public HuntState() {
			this.previoustime = 0;
			this.delayTimer = 0;
			this.timer = 0;
		}

		// Updates the clock in prep for next move??
		public void UpdateStateTimer(long CurrentGameTime) {
			this.delayTimer = CurrentGameState.DELAY;
			this.timer += this.delayTimer;
			this.previoustime = CurrentGameTime;
		}

		// Returns the StateType as Hunting
		public StateType getStateType() {
			return StateType.Hunting;
		}

		// Tells Each Ghost Where to Move
		public int getDirectionToMove(int ghost) {
			switch (ghost) {
				// Two Ghost Behaviors when Hunting
				case 0:
				case 1:
					break;
				// Other Two Ghost Behaviors when Hunting
				case 2:
				case 3:
					break;
				default:
					System.out.println("Something's wrong I think");
					break;
			}
			return 0; // WILL CHANGE
		}

		public StateType nextStateType(int ghost) {
			if (CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else {
				return StateType.NoChange;
			}
		}

		public void Reset() { }

	}

	/*
	public class FleeState implements GenericState {
		public StateType getStateType() {
			return StateType.Flee;
		}
	}

	public class LairState implements GenericState{
		public StateType getStateType() {
			return StateType.Lair;
		}
	}
	*/
}
