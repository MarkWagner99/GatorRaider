package ufl.cs1.controllers;

import game.controllers.DefenderController;
import game.models.Defender;
import game.models.Game;
import game.models.Node;

import java.util.List;

// Hey Boys this is gonna be fun
public final class StudentController implements DefenderController {

	// Private Variable Declarations
	Game PreviousGameState;
	Game CurrentGameState;
	private LairState[] lairStates = new StudentController.LairState[]{new LairState(), new LairState(), new LairState(), new LairState()};
	private HuntingState[] huntingStates = new StudentController.HuntingState[] {new HuntingState(), new HuntingState(), new HuntingState(), new HuntingState()};
	private FleeState[] fleeStates = new StudentController.FleeState[] {new FleeState(), new FleeState(), new FleeState(), new FleeState()};
	private OnStartState[] onStartStates = new StudentController.OnStartState[] {new OnStartState(), new OnStartState(), new OnStartState(), new OnStartState()};
	private GenericState[] PreviousGhostStates = new StudentController.GenericState[]{null, null, null, null};
	private GenericState[] CurrentGhostStates;


	// Constructor
	public StudentController() {
			this.CurrentGhostStates = new GenericState[] {lairStates[0], lairStates[1], lairStates[2], lairStates[3]};
	}

	// Implemented Methods
	public void init(Game game) {
	}

	public void shutdown(Game game) {
	}

	public int[] update(Game game, long CurrentGameTime) {
		int[] actions = new int[]{-1, -1, -1, -1};
		this.CurrentGameState = game;
		if (this.PreviousGameState == null){
			this.PreviousGameState = this.CurrentGameState;
		}

		// Up - Right - Down - Left -> 0 - 1 - 2 - 3
		// Anything else is no change
		for (int ghostNum = 0; ghostNum < 4; ++ghostNum){
			actions[ghostNum] = getNextAction(ghostNum, CurrentGameTime);
		}
		return actions;
	}

	/////////////////
	// New Methods //
	////////////////

	// getNextAction
	private int getNextAction(int ghostNum, long currentTime) {
		this.CurrentGhostStates[ghostNum].UpdateStateTimer(currentTime);
		StudentController.StateType newState = this.CurrentGhostStates[ghostNum].nextStateType(ghostNum);

		if (newState != StateType.NoChange) {
			switch (newState) {
				case Lair:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = lairStates[ghostNum];
					break;
				case Hunting:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = huntingStates[ghostNum];
					break;
				case Flee:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = fleeStates[ghostNum];
					break;
				case OnStart:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = onStartStates[ghostNum];
					break;
			}
		}

		int direction = CurrentGhostStates[ghostNum].getDirectionToMove(ghostNum);
		return direction;
	}

	/*
	// Rester
	public void RestAllInfo(){
		this.PreviousGhostStates = null;
		this.CurrentGhostStates = null;

		// Null problems?
		for(int iState = 0; iState < 4; ++iState) {
			this.huntingStates[iState] = new StudentController.HuntingState(null);
			this.onStartStates[iState] = new StudentController.OnStartState(null);
			this.fleeStates[iState] = new StudentController.FleeState(null);
			this.lairStates[iState] = new StudentController.LairState(null);
			this.PreviousGhostStates[iState] = null;
			this.CurrentGhostStates[iState] = this.lairStates[iState];
		}
	}
	*/

	// State Definitions
	public interface GenericState {
		void UpdateStateTimer(long CurrentGameTime);

		StudentController.StateType getStateType();

		StudentController.StateType nextStateType(int ghost);

		int getDirectionToMove(int ghost);

		void Reset();
	}

	// Types if States
	static enum StateType {
		Hunting,
		Flee,
		Lair,
		OnStart,
		NoChange;

		private StateType() {}
	}

	// Declares Methods for each of the Ghost States

	// GOOD
	public class LairState implements GenericState{
		private LairState(){
		}

		public StateType getStateType() {
			return StateType.Lair;
		}

		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).getLairTime() <= 0) {
				return StateType.OnStart;
			}
			else {
				return StateType.NoChange;
			}
		}

		public int getDirectionToMove(int ghost) {
			return -1;
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}

		public void Reset() {

		}
	}

	// GOOD
	public class OnStartState implements GenericState{
		private long previousTime;
		private long stateTimer;

		public OnStartState() {
			this.previousTime = 0;
			this.stateTimer = 0;
		}

		public StateType getStateType() {
			return StateType.OnStart;
		}

		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else if (this.stateTimer >= 3400) {
					return StateType.Hunting;

			} else {
				return StateType.NoChange;
			}
		}

		public int getDirectionToMove(int ghost) {
			Node pacManLocation = StudentController.this.CurrentGameState.getAttacker().getLocation();
			List<Node> powerPillLocations = StudentController.this.CurrentGameState.getCurMaze().getPowerPillNodes();
			if (powerPillLocations == null){
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir(pacManLocation, true);
			}
			else {
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir((Node)powerPillLocations.get(ghost), true);
			}
		}

		public void UpdateStateTimer(long CurrentGameTime) {
			this.stateTimer += 40L;
			this.previousTime = CurrentGameTime;
		}

		public void Reset() {
			this.stateTimer = 0;
			this.previousTime = 0;
		}
	}

	// Hunting down Pac-Man, two ghost going directly for Pac-Man, two more going around to try to stop Pac-Man from eating Power Pills
	public class HuntingState implements GenericState {
		private long previoustime;
		private long delayTimer;
		private long timer;

		// Constructor for HuntState
		public HuntingState() {
			this.previoustime = 0;
			this.delayTimer = 0;
			this.timer = 0;
		}

		// Returns the StateType as Hunting
		public StateType getStateType() {
			return StateType.Hunting;
		}

		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else {
				return StateType.NoChange;
			}
		}

		// Tells Each Ghost Where to Move
		public int getDirectionToMove(int ghost) {
			switch (ghost) {
				// Two Ghost Behaviors when Hunting
				case 0:
				case 1:
					break;
				// Other Two Ghost Behaviors when Hunting
				case 2:
				case 3:
					break;
				default:
					System.out.println("Something's wrong I think");
					break;
			}
			return 0; // WILL CHANGE
		}

		// Updates the clock in prep for next move??
		public void UpdateStateTimer(long CurrentGameTime) {
			this.delayTimer = CurrentGameState.DELAY;
			this.timer += this.delayTimer;
			this.previoustime = CurrentGameTime;
		}

		public void Reset() { }

	}

	// GOOD
	public class FleeState implements GenericState{
		public FleeState() {}

		public StateType getStateType() {
			return StateType.Flee;
		}

		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).getLairTime() > 0) {
				return StateType.Lair;
			} else if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.NoChange;
			}
			else {
				return StudentController.this.PreviousGhostStates[ghost].getStateType();
			}
		}

		public int getDirectionToMove(int ghost) {
			List<Node> powerPillLocations = StudentController.this.CurrentGameState.getCurMaze().getPowerPillNodes();
			if (powerPillLocations != null){
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir((Node)powerPillLocations.get(ghost), true);
			}
			else {
				return -1;
			}
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}

		public void Reset() {

		}
	}
}
