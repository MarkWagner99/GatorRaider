// Mark Wagner and Jovanny Vera
// COP 3502
// Final Project - Controlling Ghost Behaviors for PacMan
// 12-10-2017

package ufl.cs1.controllers;

import game.controllers.DefenderController;
import game.models.Defender;
import game.models.Game;
import game.models.Node;

import java.util.List;

// Hey Boys this is gonna be fun
public final class StudentController implements DefenderController {

	// Private Variable Declarations
	private Game PreviousGameState;
	private Game CurrentGameState;
	private LairState[] lairStates = new StudentController.LairState[]{new LairState(), new LairState(), new LairState(), new LairState()};
	private HuntingState[] huntingStates = new StudentController.HuntingState[] {new HuntingState(), new HuntingState(), new HuntingState(), new HuntingState()};
	private FleeState[] fleeStates = new StudentController.FleeState[] {new FleeState(), new FleeState(), new FleeState(), new FleeState()};
	private OnStartState[] onStartStates = new StudentController.OnStartState[] {new OnStartState(), new OnStartState(), new OnStartState(), new OnStartState()};
	private GenericState[] PreviousGhostStates = new StudentController.GenericState[]{null, null, null, null};
	private GenericState[] CurrentGhostStates;


	// Constructor
	public StudentController() {
			this.CurrentGhostStates = new GenericState[] {lairStates[0], lairStates[1], lairStates[2], lairStates[3]};
	}

	/////////////////////////
	// Implemented Methods //
	////////////////////////

	public void init(Game game) {
	}

	public void shutdown(Game game) {
	}

	public int[] update(Game game, long CurrentGameTime) {
		int[] actions = new int[]{-1, -1, -1, -1};
		this.CurrentGameState = game;
		if (this.PreviousGameState == null){
			this.PreviousGameState = this.CurrentGameState;
		}

		// Up - Right - Down - Left -> 0 - 1 - 2 - 3
		// Anything else is no change

		// Sends each ghost to getNextAction
		for (int ghostNum = 0; ghostNum < 4; ++ghostNum){
			actions[ghostNum] = getNextAction(ghostNum, CurrentGameTime);
		}
		// Final return from getNextAction
		return actions;
	}

	/////////////////
	// New Methods //
	////////////////

	// Determines what to do based on the state of the ghost and updates the times
	private int getNextAction(int ghostNum, long currentTime) {
		this.CurrentGhostStates[ghostNum].UpdateStateTimer(currentTime);                                     // Updates time in each state
		StudentController.StateType newState = this.CurrentGhostStates[ghostNum].nextStateType(ghostNum);    // Creates a new state determined by the nextStateType in each state

		// If there is a change in state, the current state is determined
		if (newState != StateType.NoChange) {
			switch (newState) {
				case Lair:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = lairStates[ghostNum];
					break;
				case Hunting:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = huntingStates[ghostNum];
					break;
				case Flee:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = fleeStates[ghostNum];
					break;
				case OnStart:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = onStartStates[ghostNum];
					break;
			}
		}

		// Uses the getDiretionToMove method in each state and returns that to the Update method
		int direction = CurrentGhostStates[ghostNum].getDirectionToMove(ghostNum);
		return direction;
	}

	// State Definitions
	public interface GenericState { // Each state class will have these methods
		void UpdateStateTimer(long CurrentGameTime);

		StudentController.StateType getStateType();

		StudentController.StateType nextStateType(int ghost);

		int getDirectionToMove(int ghost);
	}

	// Types of States
	static enum StateType {
		Hunting,  // The unique behaviors the ghosts use to get the PacMan
		Flee,     // The ghosts run away because they are vulnerable
		Lair,     // The ghosts are stuck in the lair until time runs out
		OnStart,  // The ghosts run to each corner when they come out of the lair
		NoChange; // No change in behavior
	}

	// Ghosts start in the lair and stay there until time runs out for each ghost
	public class LairState implements GenericState{
		// Constructor
		private LairState(){
		}

		// Returns the state
		public StateType getStateType() {
			return StateType.Lair;
		}

		// If the lair time has run out, set the ghosts free, until then they are stuck in the lair
		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).getLairTime() <= 0) {
				return StateType.OnStart;
			}
			else {
				return StateType.NoChange;
			}
		}

		// Ghosts can't move in the lair
		public int getDirectionToMove(int ghost) {
			return -1;
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}
	}

	// Sends each ghost to their respective corners
	public class OnStartState implements GenericState{
		// Uses the current time of the game to determine when it should enter the Hunting state
		private long stateTimer;

		// Constructor sets stateTimer to 0
		public OnStartState() {
			this.stateTimer = 0;
		}

		// Returns the state type
		public StateType getStateType() {
			return StateType.OnStart;
		}

		// If PacMan eats a power pill, the ghosts become vulnerable, or after 3.4 seconds the ghosts enter a hunting state
		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else if (this.stateTimer >= 3400) {
					return StateType.Hunting;

			} else {
				return StateType.NoChange;
			}
		}

		// Sends each ghost to their corners
		public int getDirectionToMove(int ghost) {
			List<Node> powerPillLocations = StudentController.this.CurrentGameState.getCurMaze().getPowerPillNodes();
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir((Node)powerPillLocations.get(ghost), true);

		}

		// Updates the time in the state
		public void UpdateStateTimer(long CurrentGameTime) {
			this.stateTimer += 40L;
		}
	}

	// Hunting down Pac-Man, ghost 1 goes directly for Pac-Man, ghost 2 goes in the direction opposite to where PacMan is going,
	// and two more going around to try to stop Pac-Man from eating Power Pills
	public class HuntingState implements GenericState {

		// Constructor for HuntState
		public HuntingState() {
		}

		// Returns the StateType as Hunting
		public StateType getStateType() {
			return StateType.Hunting;
		}

		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else {
				return StateType.NoChange;
			}
		}

		// Tells Each Ghost Where to Move based on what its unique behavior is supposed to be
		public int getDirectionToMove(int ghost) {
			Node pacManLocation = StudentController.this.CurrentGameState.getAttacker().getLocation();                   // PacMan's location in the game
			List<Node> powerPillLocations = StudentController.this.CurrentGameState.getCurMaze().getPowerPillNodes();    // Power Pill locations
			int distance = StudentController.this.CurrentGameState.getDefender(ghost).getLocation().getPathDistance(pacManLocation); // The distance between the current ghost and PacMan

			// If the distance between any ghost and PacMan is less than 25 units, the ghosts follow PacMan
			if (distance <= 25){
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir(pacManLocation, true);
			}
			else {
				// Otherwise, the ghosts follow these rules:
				switch (ghost) {
					// Directly follows PacMan
					case 0:
						return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir(pacManLocation, true);
					// Follows the Opposite Direction PacMan is heading
					case 1:
						List<Integer> ghostPossibleDirs= StudentController.this.CurrentGameState.getDefender(ghost).getPossibleDirs();
						int pacManDir = StudentController.this.CurrentGameState.getAttacker().getDirection();
						for (int i = 0; i < ghostPossibleDirs.size(); i++){
							if (ghostPossibleDirs.get(i) == pacManDir){
								return StudentController.this.CurrentGameState.getAttacker().getReverse();
							}
						}
						// or continues on current path
						return -1;
					// Other Two Ghost Behaviors Guarding Power Pills
					case 2:
							return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir((Node) powerPillLocations.get(2), true);
					case 3:
							return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir((Node) powerPillLocations.get(0), true);
					// Should never occur
					default:
							return -1;
				}
			}
		}

		// Updates the clock in prep for next move
		public void UpdateStateTimer(long CurrentGameTime) {}
	}

	// When a power pill is eaten, vulnerabe ghosts run away from PacMan
	public class FleeState implements GenericState{
		// Constructor
		private FleeState() {}

		// Returns the state type
		public StateType getStateType() {
			return StateType.Flee;
		}

		// If lair time is positive, AKA eaten, the ghost is sent to the lair
		public StateType nextStateType(int ghost) {
			if (StudentController.this.CurrentGameState.getDefender(ghost).getLairTime() > 0) {
				return StateType.Lair;
				//If the ghost is still vulnerable, there is no change
			} else if (StudentController.this.CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.NoChange;
			}
			// Otherwise, it returns to the last state it was in, most of the time hunting
			else {
				return StudentController.this.PreviousGhostStates[ghost].getStateType();
			}
		}

		// Tells the ghost to flee from the attacker according to the getNextDir method in actor, with approach as false
		public int getDirectionToMove(int ghost) {
			Node pacManLocation = StudentController.this.CurrentGameState.getAttacker().getLocation();
				return StudentController.this.CurrentGameState.getDefender(ghost).getNextDir(pacManLocation, false);
		}

		// Updates the time
		public void UpdateStateTimer(long CurrentGameTime) {

		}
	}
}
