package ufl.cs1.controllers;

import game.controllers.DefenderController;
import game.models.Defender;
import game.models.Game;

import java.util.List;

// Hey Boys this is gonna be fun
public final class StudentController implements DefenderController {

	// Private Variable Declarations
	Game PreviousGameState;
	Game CurrentGameState;
	private LairState[] lairStates = new LairState[] {null, null, null, null};
	private HuntingState[] huntingStates = new HuntingState[] {null, null, null, null};
	private FleeState[] fleeStates = new FleeState[] {null, null, null, null};
	private OnStartState[] onStartStates = new OnStartState[] {null, null, null, null};
	private GenericState[] PreviousGhostStates = new StudentController.GenericState[]{null, null, null, null};
	private GenericState[] CurrentGhostStates;


	// Constructor
	public StudentController() {
			this.CurrentGhostStates = new GenericState[] {lairStates[0], lairStates[1], lairStates[2], lairStates[3]};
	}

	// Implemented Methods
	public void init(Game game) {
	}

	public void shutdown(Game game) {
	}

	public int[] update(Game game, long CurrentGameTime) {
		int[] actions = new int[]{-1, -1, -1, -1};
		this.CurrentGameState = game;
		if (this.PreviousGameState == null){
			this.PreviousGameState = this.CurrentGameState;
		}

		// Up - Right - Down - Left -> 0 - 1 - 2 - 3
		// Anything else is no change
		for (int ghostNum = 0; ghostNum < 4; ghostNum++){
			actions[ghostNum] = getNextAction(ghostNum, CurrentGameTime);
		}
		return actions;
	}

	/////////////////
	// New Methods //
	////////////////

	// getNextAction
	public int getNextAction(int ghostNum, long currentTime) {
		this.CurrentGhostStates[ghostNum].UpdateStateTimer(currentTime);
		StateType newState = this.CurrentGhostStates[ghostNum].nextStateType(ghostNum);

		if (newState != StateType.NoChange) {
			switch (newState) {
				case Lair:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = lairStates[ghostNum];
					break;
				case Hunting:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = huntingStates[ghostNum];
					break;
				case Flee:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = fleeStates[ghostNum];
					break;
				case OnStart:
					this.PreviousGhostStates[ghostNum] = this.CurrentGhostStates[ghostNum];
					this.CurrentGhostStates[ghostNum] = onStartStates[ghostNum];
					break;
			}
		}

		int direction = CurrentGhostStates[ghostNum].getDirectionToMove(ghostNum);
		return direction;
	}

	// Rester
	public void RestAllInfo(){
		this.PreviousGhostStates = null;
		this.CurrentGhostStates = null;

		// Null problems?
		for(int iState = 0; iState < 4; ++iState) {
			this.huntingStates[iState] = new StudentController.HuntingState(null);
			this.onStartStates[iState] = new StudentController.OnStartState(null);
			this.fleeStates[iState] = new StudentController.FleeState(null);
			this.lairStates[iState] = new StudentController.LairState(null);
			this.PreviousGhostStates[iState] = null;
			this.CurrentGhostStates[iState] = this.lairStates[iState];
		}
	}



	// State Definitions
	public interface GenericState {
		void UpdateStateTimer(long CurrentGameTime);

		StudentController.StateType getStateType();

		StudentController.StateType nextStateType(int ghost);

		int getDirectionToMove(int ghost);

		void Reset();
	}

	// Types if States
	static enum StateType {
		Hunting,
		Flee,
		Lair,
		OnStart,
		NoChange;
	}

	// Declares Methods for each of the Ghost States

	// Hunting down Pac-Man, two ghost going directly for Pac-Man, two more going around to try to stop Pac-Man from eating Power Pills
	public class HuntingState implements GenericState {
		private long previoustime;
		private long delayTimer;
		private long timer;

		// Constructor for HuntState
		public HuntingState() {
			this.previoustime = 0;
			this.delayTimer = 0;
			this.timer = 0;
		}

		// Updates the clock in prep for next move??
		public void UpdateStateTimer(long CurrentGameTime) {
			this.delayTimer = CurrentGameState.DELAY;
			this.timer += this.delayTimer;
			this.previoustime = CurrentGameTime;
		}

		// Returns the StateType as Hunting
		public StateType getStateType() {
			return StateType.Hunting;
		}

		// Tells Each Ghost Where to Move
		public int getDirectionToMove(int ghost) {
			switch (ghost) {
				// Two Ghost Behaviors when Hunting
				case 0:
				case 1:
					break;
				// Other Two Ghost Behaviors when Hunting
				case 2:
				case 3:
					break;
				default:
					System.out.println("Something's wrong I think");
					break;
			}
			return 0; // WILL CHANGE
		}

		public StateType nextStateType(int ghost) {
			if (CurrentGameState.getDefender(ghost).isVulnerable()) {
				return StateType.Flee;
			} else {
				return StateType.NoChange;
			}
		}

		public void Reset() { }

	}

	// NEEDS TO BE FIXED
	public class LairState implements GenericState{
		private LairState(){
		}

		public StateType getStateType() {
			return StateType.Lair;
		}

		public StateType nextStateType(int ghost) {
			return null;
		}

		public int getDirectionToMove(int ghost) {
			return 0;
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}

		public void Reset() {

		}
	}

	// NEEDS TO BE FIXED
	public class FleeState implements GenericState{
		public FleeState() {}

		public StateType getStateType() {
			return StateType.Flee;
		}

		public StateType nextStateType(int ghost) {
			return null;
		}

		public int getDirectionToMove(int ghost) {
			return 0;
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}

		public void Reset() {

		}
	}

	// NEEDS TO BE FIXED
	public class OnStartState implements GenericState{
		public OnStartState() {}

		public StateType getStateType() {
			return StateType.OnStart;
		}

		public StateType nextStateType(int ghost) {
			return null;
		}

		public int getDirectionToMove(int ghost) {
			return 0;
		}

		public void UpdateStateTimer(long CurrentGameTime) {

		}

		public void Reset() {

		}
	}
}
